package java020_thread.prob;

public class Prob001_thread {

	public static void main(String[] args) {		

	}//end main()

}//end class
