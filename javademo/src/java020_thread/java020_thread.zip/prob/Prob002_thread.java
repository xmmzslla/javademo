package java020_thread.prob;

public class Prob002_thread {

	public static void main(String[] args) {
		

	}//end main()

}//end class
