package java018_collection.answ;

public class Sports {
	private String code;
	private String program;
	
	public Sports(String code, String program) {
		this.code=code;
		this.program=program;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getProgram() {
		return program;
	}

	public void setProgram(String program) {
		this.program = program;
	}

}
